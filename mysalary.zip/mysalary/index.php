<?php ob_start(); ?>
<?php session_start(); ?>
<?php require_once("includes/connect.php"); ?>
<?php require_once("includes/functions.php"); ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Salary Calculator</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	 <!-- You can use Open Graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
  <!--<meta property="fb:app_id"        content="161336481463790" /> -->
  <meta property="og:url"           content="https://sayarihost.com/mylocation/" /> 
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="My Location" />
  <meta property="og:description"   content="My Location" />
  <meta property="og:image"         content="https://sayarihost.com/mylocation/images/a.png" />
    
	
	
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
  <div class="limiter">
	<div class="container-login100">
      <div class="wrap-login100">
		<div class="login100-form-title" style="background-image: url(images/a.png);">
		  <span class="login100-form-title-1">
			<a href="https://startpoint.co.tz/" target="_blank" class="btn btn-primary">Home > </a> Salary Calculator
		  </span>
		</div>
		
		 <div><?php 
         if(isset($_SESSION['SuccessMessage'])){
		   echo SuccessMessage();
		   unset($_SESSION["SuccessMessage"]);
		}
	      ?>
       </div>

				<form action="add_salary.php" method="POST" enctype="multipart/form-data" class="login100-form validate-form" AUTOCOMPLETE="OFF">
					<div class="wrap-input100 validate-input m-b-26" data-validate="Basic Salary required">
						<span class="label-input100">Basic_Salary</span>
						<input class="input100" type="number" name="basic" placeholder="Enter Basic Salary">
					</div>
					<div class="wrap-input100 m-b-26" data-validate="Allowances: are required">
						<span class="label-input100">Allowances:</span>
						<input class="input100" type="number" name="allowances" placeholder="Enter Allowances">
					</div>
					
					<div class="wrap-input100 validate-input m-b-26" data-validate="HESLB 15% required">
					  <span class="label-input100">HESLB 15%</span>						
				    <li href='#' class='wrap-input100' style=''>
                      <div class="form-check form-check-inline">
                        <input type="radio" class="wrap-input100" value="1" id="materialInline1" name="heslb">
                        <label class="form-check-label" for="materialInline1">Yes</label>
                       </div>
                      <div class="form-check form-check-inline">
                        <input type="radio" class="wrap-input100" value="0" id="materialInline2" name="heslb" checked>
                        <label class="form-check-label" for="materialInline2">No</label>
                      </div>
                    </li>
					</div>
					
					<div class="wrap-input100 validate-input m-b-26" data-validate="NHIF 3% required">
					  <span class="label-input100">NHIF 3%</span>
						<li href='#' class='wrap-input100' style=''>
                          <div class="form-check form-check-inline">
                             <input type="radio" class="wrap-input100" value="1" id="materialInline1" name="nhif">
                             <label class="form-check-label" for="materialInline1">Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                             <input type="radio" class="wrap-input100" value="0" id="materialInline2" name="nhif" checked>
                             <label class="form-check-label" for="materialInline2">No</label>
                          </div>
                        </li> 
					</div>
					
					<div class="wrap-input100 validate-input m-b-26" data-validate="NSSF 10% required">
					  <span class="label-input100">NSSF 10%</span>
						<li href='#' class='wrap-input100' style=''>
                          <div class="form-check form-check-inline">
                             <input type="radio" class="wrap-input100" value="1" id="materialInline1" name="nssf">
                             <label class="form-check-label" for="materialInline1">Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                             <input type="radio" class="wrap-input100" value="0" id="materialInline2" name="nssf" checked>
                             <label class="form-check-label" for="materialInline2">No</label>
                          </div>
                        </li> 
					</div>		
			
					<div class="container-login100-form-btn">
					   <input type="Submit" class="login100-form-btn" id="btnAddProduct" value="View Take Home Salary" >
					</div>
				</form>
			</div>
		</div>
	</div>

	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>