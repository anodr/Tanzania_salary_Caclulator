<?php ob_start();
session_start();
require_once('tcpdf/tcpdf.php');
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Dario Balas');
$pdf->SetTitle('PDF');
$pdf->SetSubject('PDF');
$pdf->SetKeywords('PDF');

$pdf->setPrintHeader(true);
$pdf->setPrintFooter(true);

$PDF_HEADER_LOGO = "../img/logo.jpg";//any image file. check correct path.
$PDF_HEADER_LOGO_WIDTH = "10";
$PDF_HEADER_TITLE = "StartPoint Technologies";
$PDF_HEADER_STRING = "Tel +255 737 139 504 / 255 759 876 418\n"
. "Email: info@startpoint.co.tz\n"
. "www.startpoint.co.tz\n";
//$pdf->SetHeaderData($PDF_HEADER_LOGO, $PDF_HEADER_LOGO_WIDTH, $PDF_HEADER_TITLE, $PDF_HEADER_STRING);

$pdf->SetHeaderData($PDF_HEADER_LOGO, $PDF_HEADER_LOGO_WIDTH, $PDF_HEADER_TITLE.' 001', $PDF_HEADER_STRING, array(0,64,255), array(0,64,128));
$pdf->setFooterData(array(0,64,0), array(0,64,128));

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

if (@file_exists(dirname(_FILE_).'/lang/eng.php')) {
    require_once(dirname(_FILE_).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}
$pdf->SetFont('helvetica', '', 10);
$pdf->AddPage();

$html = '

<br>

<h3 style="text-align:center;">SALARY SLIP</h3>

<br><br>

<table width="100%" border="0.5px" style="padding: 5px;">
       <tr style="background-color:#5c6bc0; color:white;">
		  <th style="width:30%;">Details:</th>
	      <th style="width:50%;">Amount</th>
		</tr>';

   try{
              require_once('includes/connect.php');
               
			  if(isset($_SESSION['login'])){
		      $Administator = $_SESSION['id'];
		       }  
   
              $ViewPostFromId=$_GET['id']; 
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			  
			  $res1 = $conn->prepare("SELECT basic as BasicSalary FROM salary WHERE salary_id='$ViewPostFromId' ");
              $res1->execute();
              $row = $res1->fetch(PDO::FETCH_ASSOC);
	
              $BasicSalary =  ($row['BasicSalary']);
			  
			  $res1 = $conn->prepare("SELECT allowances as AllowanceAmount FROM salary WHERE salary_id='$ViewPostFromId' ");
              $res1->execute();
              $row = $res1->fetch(PDO::FETCH_ASSOC);
	
              $AllowanceAmount =  ($row['AllowanceAmount']);
			  
			  $Gross =  ($BasicSalary + $AllowanceAmount);
			  
   $res1 = $conn->prepare("SELECT basic as PaidBasicSalary FROM salary WHERE salary_id='$ViewPostFromId' ");
   $res1->execute();
   $row = $res1->fetch(PDO::FETCH_ASSOC);
	
   $res2 = $conn->prepare("SELECT heslb AS HESLB FROM salary WHERE heslb='1' AND salary_id='$ViewPostFromId' ");
   $res2->execute();
   $row2 = $res2->fetch(PDO::FETCH_ASSOC);
   
   $res3 = $conn->prepare("SELECT nhif AS NHIF FROM salary WHERE nhif='1' AND salary_id='$ViewPostFromId' ");
   $res3->execute();
   $row3 = $res3->fetch(PDO::FETCH_ASSOC);
   
   $res4 = $conn->prepare("SELECT nssf AS NSSF FROM salary WHERE nssf='1' AND salary_id='$ViewPostFromId' ");
   $res4->execute();
   $row4 = $res4->fetch(PDO::FETCH_ASSOC);
	
   if(($row2['HESLB']) == 1){
	   $HESLB = ($BasicSalary * 0.15);
   }else{
	   $HESLB = 0;
   }	
   
   if(($row3['NHIF']) == 1){
	   $NHIF = ($Gross * 0.03);
   }else{
	   $NHIF = 0;
   }
   
   if(($row4['NSSF']) == 1){
	   $NSSF = ($Gross * 0.1);
   }else{
	   $NSSF = 0;
   }
		  

	if($BasicSalary<300000){
	   $NHIFTOPUP = (18000 -($NHIF*2));
        }else{
	   $NHIFTOPUP = ($NHIF*2);
          }
              
   $Taxable = ($Gross -($NHIF+$NSSF));
			  
   $Deductions =  ($HESLB + $NHIF + $NSSF);
   
   $X =  ($Gross - $Deductions);

   if($X>720000){
	   $PAYE = (98100 + (0.3 * ($X-720000)));
   }
   
   if($X>540000){
	   $PAYE = (53100 + (0.25 * ($X-540000)));
   }
   
   if($X>360000){
	   $PAYE = (17100 + (0.2 * ($X-360000)));
   }
   
   if($X>170000){
	   $PAYE = (0.09 * ($X-170000));
   }
			  
	$NetSalary = ($Taxable - ($PAYE + $HESLB)); 

    $SDL = ($Gross*0.045); 

    $WCF = ($Gross*0.01); 

    $TotalCompanyCost = ($Gross+$NHIF+$NHIFTOPUP+$NSSF+$SDL+$WCF);  	
			  
			  $stmt = $conn->prepare("SELECT * FROM salary WHERE salary_id='$ViewPostFromId' ");	
              $stmt->execute();
	          $SrNo=0;
			  
			  $stmt->bindColumn('salary_id', $Id);
			  $stmt->bindColumn('basic', $basic);
			  $stmt->bindColumn('allowances', $amount);
			  $stmt->bindColumn('datesalary', $DateTime);

              $errorInfo = $conn->errorInfo();
              //print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
              while ($row = $stmt->fetch()) {
              $SrNo++;	
    // concatenate a string, instead of calling $pdf->writeHTML()

			
	$html .= '<tr>
	            <td colspan="1" align="right">Basic Salary</td>
				<td align="right">'.number_format($BasicSalary).'</td> 			
			</tr>';	
}
    
    $html .= '<tr>
	            <td colspan="1" align="right">Allowances</td>
				<td  align="right" >'.number_format($AllowanceAmount).'</td>  
			</tr>';	
			
	$html .= '<tr>
	            <td colspan="1" align="right" style="background-color:#e0e0e0; color:black;">Gross Salary</td>
				<td  align="right" style="background-color:#e0e0e0; color:black;">'.number_format($Gross).'</td>  
			</tr>';			
			
	$html .= '<tr>
	            <td colspan="1" align="right">HESLB (15%)</td>
				<td  align="right" >'.number_format($HESLB).'</td>  
			</tr>';	
			
	$html .= '<tr>
	            <td colspan="1" align="right">NHIF - EE(3%)</td>
				<td  align="right">'.number_format($NHIF).'</td>  
			</tr>';		

    $html .= '<tr>
	            <td colspan="1" align="right">NHIF - ER(3%)</td>
				<td  align="right" >'.number_format($NHIF).'</td>  
			</tr>';	
			
	$html .= '<tr>
	            <td colspan="1" align="right">NHIF - ER TopUp (3%)</td>
				<td  align="right">'.number_format($NHIFTOPUP).'</td>  
			</tr>';		

    $html .= '<tr>
	            <td colspan="1" align="right">NSSF - EE (10%)</td>
				<td  align="right" >'.number_format($NSSF).'</td>  
			</tr>';	
			
	$html .= '<tr>
	            <td colspan="1" align="right">NSSF - ER (10%)</td>
				<td  align="right">'.number_format($NSSF).'</td>  
			</tr>';		

    $html .= '<tr>
	            <td colspan="1" align="right" style="background-color:#e0e0e0; color:black;">Taxable Income</td>
				<td  align="right" style="background-color:#e0e0e0; color:black;">'.number_format($Taxable).'</td>  
			</tr>';	
			
	$html .= '<tr>
	            <td colspan="1" align="right">PAYE</td>
				<td  align="right">'.number_format($PAYE).'</td>  
			</tr>';	
			
	$html .= '<tr>
	            <td colspan="1" align="right" style="background-color:#5c6bc0; color:white;">Take Home Salary</td>
				<td  align="right" style="background-color:#5c6bc0; color:white;">'.number_format($NetSalary).'</td>  
			</tr>';			

    $html .= '<tr>
	            <td colspan="1" align="right">SDL</td>
				<td  align="right" >'.number_format($SDL).'</td>  
			</tr>';	
			
	$html .= '<tr>
	            <td colspan="1" align="right">WCF</td>
				<td  align="right">'.number_format($WCF).'</td>  
			</tr>';		

    $html .= '<tr>
	            <td colspan="1" align="right" style="background-color:#e0e0e0; color:black;">TOTAL COMPANY COST</td>
				<td  align="right" style="background-color:#e0e0e0; color:black;">'.number_format($TotalCompanyCost).'</td>  
			</tr>';	

    $html .= '<tr>
	            <td colspan="5" align="left" style="height:50px;"><br>Official Stamp: . . . . . . . . . . . . . .</td> 
			</tr>';	

    $html .= '<tr>
	            <td colspan="5" align="Center">Thank you ! </td> 
			</tr>';	
    
	$html .= '<tr>
	            <td colspan="1" align="left">Employee Name</td>
				<td colspan="2" align="left">........................</td>  
			</tr>';
			
	$html .= '<tr>
	            <td colspan="1" align="left">Company</td>
				<td colspan="2" align="left">........................</td>  
			</tr>';		
			
	$html .= '<tr>
	            <td colspan="1" align="left">Address</td>
				<td colspan="2" align="left">........................</td>  
			</tr>';

    $html .= '<tr>
	            <td colspan="1" align="left">Location</td>
				<td colspan="2" align="left">........................</td>  
			</tr>';		
    			
	$html .= '<tr>
	            <td colspan="1" align="left">Date Issued</td>
				<td colspan="2" align="left">'.($DateTime).'</td>  
			</tr>';				
 
$html .= '</table>';

$pdf->writeHTML($html, true, 0, true, 0);
$pdf->lastPage();
ob_end_clean();
$pdf->Output(''.$BasicSalary.'_receipt.pdf', 'I');
header("Location: https://startpoint.co.tz/");
?>