<?php ob_start(); 
session_start();
?>
<?php
try{
   require_once('includes/connect.php');
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   if(isset($_POST) & !empty($_POST)){
   $CurrentTime=time();
   date_default_timezone_set('Africa/Dar_es_Salaam');
   $DateTime=strftime('%Y-%m-%d %H:%M:%S',$CurrentTime);

   $sql = "INSERT INTO salary(basic,allowances,heslb,nhif,nssf,datesalary) VALUES
           (:basic, :allowances, :heslb, :nhif, :nssf, :datesalary)";
   $result = $conn->prepare($sql);
   $result->bindParam(':basic', htmlspecialchars($_POST['basic']),PDO::PARAM_INT);
   $result->bindParam(':allowances', htmlspecialchars($_POST['allowances']),PDO::PARAM_INT);
   $result->bindParam(':heslb', htmlspecialchars($_POST['heslb']),PDO::PARAM_INT); 
   $result->bindParam(':nhif', htmlspecialchars($_POST['nhif']),PDO::PARAM_INT); 
   $result->bindParam(':nssf', htmlspecialchars($_POST['nssf']),PDO::PARAM_INT);    
   $result->bindParam(':datesalary', htmlspecialchars($DateTime),PDO::PARAM_STR);
   $res = $result->execute();

  if($res){
  $_SESSION["SuccessMessage"]="View Salary Calculations";
  header('Location: mysalary.php?id='.$conn->lastInsertID().'');
  }else{
  $_SESSION["ErrorMessage"]="Something went wrong. Try again";
  header("Location: index.php");
  }
   
}
}catch(Exception $e){
	$error = $e->getMessage();

}
if(isset($error)){echo "Errors : ". $error;}
	var_dump($res);

	//echo $result . " Records Inserted in DB" .$db->lastInsertID();
	
	
	
	
	
	
	
	
	