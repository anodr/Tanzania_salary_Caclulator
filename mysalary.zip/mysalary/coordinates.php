<p>Click the button to get your coordinates.</p>

<button onclick="getLocation()">Try It</button>
<br>
<p id="demo" id="text" onclick="copyElementText(this.id)" ></p>


<script>
function myFunction() {
  var copyText = document.getElementById("demo");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}
</script>


<script>
var x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = + position.coords.latitude + 
  "," + position.coords.longitude;
}
</script>





<script>
function copyElementText(id) {
    var text = document.getElementById(id).innerText;
    var elem = document.createElement("textarea");
    document.body.appendChild(elem);
    elem.value = text;
    elem.select();
    document.execCommand("copy");
    document.body.removeChild(elem);
}

</script>
