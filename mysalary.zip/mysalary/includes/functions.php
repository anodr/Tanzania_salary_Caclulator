<?php ob_start(); ?>
<?php require_once("connect.php"); ?>
<?php //require_once("sessions.php"); ?>

<?php
//function Redirect_to($New_Location){
//    header("Location:".$New_Location);
//	exit;
//}

function Login_Attempt($username,$password){
	$ConnectingDB;
	$connection=mysqli_connect("localhost","econneck_logisti","jz==jOwusq,_"," econneck_logistics");
	$query="SELECT * FROM registration WHERE username='$username' AND password='$password'";
	$result=mysqli_query($connection, $query);
	if($admin=mysqli_fetch_assoc($result)){
		return $admin;
	}else
		return null;
}

function Login(){
	if(isset($_SESSION["id"])){
		return true;
	}
}
function Confirm_Login(){
	if(!Login()){
		$_SESSION["ErrorMessage"]="Login Required";
		header("Location: ../simplelogin/login.php");
	}
}

function ConfirmFrontPage_Login(){
	if(!Login()){
		$_SESSION["ErrorMessage"]="Login Required";
		header("Location: simplelogin/login.php");
	}
}

function SuccessMessage(){
    if(isset($_SESSION["SuccessMessage"])){
       $Output="<div class=\"alert alert-success\">" ;
       $Output.=htmlentities($_SESSION["SuccessMessage"]);
       $Output.="</div>";
       $_SESSION["SuccessMessage"]=null;
       return $Output;
        
        
    }
}

?>