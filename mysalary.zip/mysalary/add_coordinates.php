<?php ob_start();
session_start(); ?>
<?php
try{
   require_once('includes/connect.php');
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   if(isset($_POST) & !empty($_POST)){
   $CurrentTime=time();
   date_default_timezone_set('Africa/Dar_es_Salaam');
   $DateTime=strftime('%Y-%m-%d %H:%M:%S',$CurrentTime);
   if(isset($_SESSION['login'])){
		  $Admin = $_SESSION['id'];
		}
   
   $sql = "INSERT INTO coordinates(coordinates,datecoordinates)
	       VALUES(:coordinates, :datecoordinates)";
   $result = $conn->prepare($sql);
   $result->bindParam(':coordinates', htmlspecialchars($_POST['coordinates']),PDO::PARAM_STR);
   $result->bindParam(':datecoordinates', htmlspecialchars($DateTime),PDO::PARAM_STR);
   $res = $result->execute();

  if($res){
  $_SESSION["SuccessMessage"]="Coordinates Added Successfully";
  header('Location: ' . $_SERVER['HTTP_REFERER']);
  }else{
  $_SESSION["ErrorMessage"]="Something went wrong. Try again";
  header("Location: index.php");
  }
   
}
}catch(Exception $e){
	$error = $e->getMessage();

}
if(isset($error)){echo "Errors : ". $error;}
	var_dump($res);

	//echo $result . " Records Inserted in DB" .$db->lastInsertID();
?>
	
	
	