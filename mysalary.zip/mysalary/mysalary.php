<?php ob_start(); ?>
<?php session_start(); ?>
<?php require_once("includes/connect.php"); ?>
<?php require_once("includes/functions.php"); ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Salary Calculator</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	 <!-- You can use Open Graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
  <!--<meta property="fb:app_id"        content="161336481463790" /> -->
  <meta property="og:url"           content="https://sayarihost.com/mylocation/" /> 
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="My Location" />
  <meta property="og:description"   content="My Location" />
  <meta property="og:image"         content="https://sayarihost.com/mylocation/images/a.png" />
    
	
	
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
  <div class="limiter">
	<div class="container-login100">
      <div class="wrap-login100">
		<div class="login100-form-title" style="background-image: url(images/a.png);">
		  <span class="login100-form-title-1">
			<a href="https://startpoint.co.tz/" target="_blank" class="btn btn-primary">Home > </a> Salary Calculator
		  </span>
		</div>
		
		 <div class="col-md-12" style="margin-bottom:20px">
		 
		  <br>

<h5 class="text-center">PAYROLL - DETAILS</h5>

	<hr>

<?php

   $ViewPostFromId=$_GET["id"];
	
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   $res1 = $conn->prepare("SELECT basic as BasicSalary FROM salary WHERE salary_id='$ViewPostFromId' ");
   $res1->execute();
   $row = $res1->fetch(PDO::FETCH_ASSOC);
	
   $BasicSalary =  ($row['BasicSalary']);	

   echo "<li href='#' class='list-group-item list-group-item-action' style='background-color:#2E99F2; color:white;'>";
     echo 'Basic Salary:&nbsp;';  echo "<span class='pull-right'>".number_format($BasicSalary)."</span>";
   echo "</li>";

	
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   $res1 = $conn->prepare("SELECT allowances as AllowanceAmount FROM salary WHERE salary_id='$ViewPostFromId' ");
   $res1->execute();
   $row = $res1->fetch(PDO::FETCH_ASSOC);
	
   $AllowanceAmount =  ($row['AllowanceAmount']);
	
	echo "<li href='#' class='list-group-item list-group-item-action'>";
      echo 'Allowances:&nbsp;'; echo "<span class='pull-right'>".number_format($AllowanceAmount)."</span>";
	echo "</li>";

	$Gross =  ($BasicSalary + $AllowanceAmount);
	
   echo "<li href='#' class='list-group-item list-group-item-action' style='background-color:#4285F4; color:white;'>";
     echo 'Gross Salary:&nbsp;'; echo "<span class='pull-right'>".number_format($Gross)."</span>";
   echo "</li>";
   
   echo "<li href='#' class='list-group-item list-group-item-action' style='background-color:; color:;'>";
     echo ''; echo "<span class='text-center'></span>";
   echo "</li>";
	
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   $res1 = $conn->prepare("SELECT basic as PaidBasicSalary FROM salary WHERE salary_id='$ViewPostFromId' ");
   $res1->execute();
   $row = $res1->fetch(PDO::FETCH_ASSOC);
	
   $res2 = $conn->prepare("SELECT heslb AS HESLB FROM salary WHERE heslb='1' AND salary_id='$ViewPostFromId' ");
   $res2->execute();
   $row2 = $res2->fetch(PDO::FETCH_ASSOC);
   
   $res3 = $conn->prepare("SELECT nhif AS NHIF FROM salary WHERE nhif='1' AND salary_id='$ViewPostFromId' ");
   $res3->execute();
   $row3 = $res3->fetch(PDO::FETCH_ASSOC);
   
   $res4 = $conn->prepare("SELECT nssf AS NSSF FROM salary WHERE nssf='1' AND salary_id='$ViewPostFromId' ");
   $res4->execute();
   $row4 = $res4->fetch(PDO::FETCH_ASSOC);
	
   if(($row2['HESLB']) == 1){
	   $HESLB = ($BasicSalary * 0.15);
   }else{
	   $HESLB = 0;
   }	
   
   if(($row3['NHIF']) == 1){
	   $NHIF = ($Gross * 0.03);
   }else{
	   $NHIF = 0;
   }
   
   if(($row4['NSSF']) == 1){
	   $NSSF = ($Gross * 0.1);
   }else{
	   $NSSF = 0;
   }

   echo "<li href='#' class='list-group-item list-group-item-action' >";
     echo 'HESLB (15%):&nbsp;';  echo "<span class='pull-right'>".number_format($HESLB)."</span>";
   echo "</li>";
   	
   echo "<li href='#' class='list-group-item list-group-item-action' >";
     echo 'NHIF - EE(3%):&nbsp;';  echo "<span class='pull-right'>".number_format($NHIF)."</span>";
   echo "</li>";
   
   //NHIF ER
   
   echo "<li href='#' class='list-group-item list-group-item-action' >";
     echo 'NHIF - ER(3%):&nbsp;';  echo "<span class='pull-right'>".number_format($NHIF)."</span>";
   echo "</li>";
   
   //NHIF TOP UP
   
   if($BasicSalary<300000){
	   $NHIFTOPUP = (18000 -($NHIF*2));
   }else{
	   $NHIFTOPUP = ($NHIF*2);
   }
	
   echo "<li href='#' class='list-group-item list-group-item-action' >";
     echo 'NHIF - ER TopUp (3%):&nbsp;';  echo "<span class='pull-right'>".number_format($NHIFTOPUP)."</span>";
   echo "</li>";
   
   //NSSF
      
   echo "<li href='#' class='list-group-item list-group-item-action' >";
     echo 'NSSF - EE (10%):&nbsp;';  echo "<span class='pull-right'>".number_format($NSSF)."</span>";
   echo "</li>";
   
   echo "<li href='#' class='list-group-item list-group-item-action' >";
     echo 'NSSF - ER (10%):&nbsp;';  echo "<span class='pull-right'>".number_format($NSSF)."</span>";
   echo "</li>";
   
   echo "<li href='#' class='list-group-item list-group-item-action' >";
     echo '';  echo "<span class='pull-right'></span>";
   echo "</li>";
   
   //Taxable Income
   
   $Taxable = ($Gross -($NHIF+$NSSF));
   
   echo "<li href='#' class='list-group-item list-group-item-action' style='background-color:#6d4c41; color:white'>";
	 echo 'Taxable Income:&nbsp;';  echo "<span class='pull-right'>".number_format($Taxable)."</span>";
	echo "</li>";
	
	//PAYE
	
   $Deductions =  ($HESLB + $NHIF + $NSSF);
   
   $X =  ($Gross - $Deductions);

   if($X>720000){
	   $PAYE = (98100 + (0.3 * ($X-720000)));
   }
   
   if($X>540000){
	   $PAYE = (53100 + (0.25 * ($X-540000)));
   }
   
   if($X>360000){
	   $PAYE = (17100 + (0.2 * ($X-360000)));
   }
   
   if($X>170000){
	   $PAYE = (0.09 * ($X-170000));
   }

	echo "<li href='#' class='list-group-item list-group-item-action'>";
	 echo 'PAYE:&nbsp;';  echo "<span class='pull-right'>".number_format($PAYE)."</span>";
	echo "</li>";

    //NET SALARY

     $NetSalary = ($Taxable - ($PAYE + $HESLB));    

	echo "<li href='#' class='list-group-item list-group-item-action' style='background-color:#2E99F2; color:white;'>";
	 echo 'NET SALARY:&nbsp;';  echo "<span class='pull-right'>".number_format($NetSalary)."</span>";
	echo "</li>";

    //SDL

    $SDL = ($Gross*0.045);    

	echo "<li href='#' class='list-group-item list-group-item-action'>";
	 echo 'SDL:&nbsp;';  echo "<span class='pull-right'>".number_format($SDL)."</span>";
	echo "</li>";
	
	//WCF

    $WCF = ($Gross*0.01);    

	echo "<li href='#' class='list-group-item list-group-item-action'>";
	 echo 'WCF:&nbsp;';  echo "<span class='pull-right'>".number_format($WCF)."</span>";
	echo "</li>";
	
	
	//TOTAL COMPANY COST

    $TotalCompanyCost = ($Gross+$NHIF+$NHIFTOPUP+$NSSF+$SDL+$WCF);    

	echo "<li href='#' class='list-group-item list-group-item-action' style='background-color:#2E99F2; color:white;'>";
	 echo 'TOTAL COMPANY COST:&nbsp;';  echo "<span class='pull-right'>".number_format(($TotalCompanyCost),2)."</span>";
	echo "</li>";
?>

<hr>
<div class="container-login100-form-btn">
 <a href="printslip.php?id=<?php echo $ViewPostFromId; ?>" target="_blank" class="btn btn-primary">Print</a>
</div>
</div>

			</div>
		</div>
	</div>

	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>